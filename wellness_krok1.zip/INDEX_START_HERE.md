# START HERE
To jest automatycznie wygenerowany zestaw plików dla KROK 1.
Uruchom RUN_EVERYTHING.sh aby zainstalować.